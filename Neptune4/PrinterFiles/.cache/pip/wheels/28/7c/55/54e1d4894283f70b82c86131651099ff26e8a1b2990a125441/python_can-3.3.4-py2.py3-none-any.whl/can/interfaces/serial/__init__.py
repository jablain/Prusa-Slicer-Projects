# coding: utf-8

"""
"""

from can.interfaces.serial.serial_can import SerialBus as Bus
